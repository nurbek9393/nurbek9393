# Telegram Video Uploader Bot 🤖🎥

Бот принимает видео от пользователей и сохраняет их на сервере.

## 🚀 Запуск локально

1. Установи зависимости:
   ```bash
   pip install -r requirements.txt
